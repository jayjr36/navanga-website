# Security Policy

## Supported Versions

| Version | Supported |
| ------- | ------------------ |
| 0.x | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security vulnerability within the package, please email Dan Harrin via [dan@danharrin.com](mailto:dan@danharrin.com). All security vulnerabilities will be promptly addressed.
