<?php

return [

    'messages' => [
        'copied' => 'Copiado',
    ],

];
