<?php

return [

    'messages' => [
        'uploading_file' => 'Se încarcă fișierul...',
    ],

];
