<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Închide',
        ],

    ],

];
