<?php

return [

    'messages' => [
        'copied' => 'คัดลอกแล้ว',
    ],

];
