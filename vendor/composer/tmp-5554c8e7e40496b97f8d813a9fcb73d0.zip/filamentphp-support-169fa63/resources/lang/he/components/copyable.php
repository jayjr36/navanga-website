<?php

return [

    'messages' => [
        'copied' => 'הועתק',
    ],

];
