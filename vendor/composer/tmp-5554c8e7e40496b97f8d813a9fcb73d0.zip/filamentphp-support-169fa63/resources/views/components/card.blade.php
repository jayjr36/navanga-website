<x-filament::section>
    {{ $slot }}
</x-filament::section>
