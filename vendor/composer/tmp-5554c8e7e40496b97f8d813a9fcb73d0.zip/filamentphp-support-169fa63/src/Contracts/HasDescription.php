<?php

namespace Filament\Support\Contracts;

interface HasDescription
{
    public function getDescription(): ?string;
}
