<?php

namespace Filament\Support\Contracts;

interface HasIcon
{
    public function getIcon(): ?string;
}
