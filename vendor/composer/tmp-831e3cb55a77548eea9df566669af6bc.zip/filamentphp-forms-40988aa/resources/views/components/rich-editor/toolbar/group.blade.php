<div {{ $attributes->class(['flex gap-x-1']) }}>
    {{ $slot }}
</div>
