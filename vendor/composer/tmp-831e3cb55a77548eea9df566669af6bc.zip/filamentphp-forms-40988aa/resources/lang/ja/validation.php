<?php

return [

    'distinct' => [
        'must_be_selected' => '少なくとも1つ以上:attributeを選択してください',
        'only_one_must_be_selected' => '1つだけ:attributeを選択してください',
    ],

];
