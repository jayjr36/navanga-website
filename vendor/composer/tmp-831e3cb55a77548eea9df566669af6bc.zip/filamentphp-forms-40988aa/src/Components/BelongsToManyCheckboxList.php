<?php

namespace Filament\Forms\Components;

/**
 * @deprecated Use `CheckboxList` with the `relationship()` method instead.
 */
class BelongsToManyCheckboxList extends CheckboxList
{
}
