<?php

return [

    'modal' => [

        'heading' => 'Jakinarazpenak',

        'actions' => [

            'clear' => [
                'label' => 'Ezabatu',
            ],

            'mark_all_as_read' => [
                'label' => 'Denak irakurrita bezala markatu',
            ],

        ],

        'empty' => [
            'heading' => 'Ez dago jakinarazpenik',
            'description' => 'Mesedez, egiaztatu geroago',
        ],

    ],

];
