<?php

return [

    'modal' => [

        'heading' => 'Njoftimet',

        'actions' => [

            'clear' => [
                'label' => 'Pastro',
            ],

            'mark_all_as_read' => [
                'label' => 'Shënoni të gjitha si të lexuara',
            ],

        ],

        'empty' => [
            'heading' => 'Nuk ka njoftime',
            'description' => 'Ju lutemi kontrolloni përsëri më vonë.',
        ],

    ],

];
