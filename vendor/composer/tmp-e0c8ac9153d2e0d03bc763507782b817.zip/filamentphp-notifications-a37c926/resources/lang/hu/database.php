<?php

return [

    'modal' => [

        'heading' => 'Értesítések',

        'actions' => [

            'clear' => [
                'label' => 'Törlés',
            ],

            'mark_all_as_read' => [
                'label' => 'Összes olvasottnak jelölése',
            ],

        ],

        'empty' => [
            'heading' => 'Nincsenek értesítések',
            'description' => 'Kérjük, hogy nézz vissza később.',
        ],

    ],

];
