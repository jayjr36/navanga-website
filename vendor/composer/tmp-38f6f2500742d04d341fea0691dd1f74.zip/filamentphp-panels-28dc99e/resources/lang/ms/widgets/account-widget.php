<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Log keluar',
        ],

    ],

    'welcome' => 'Selamat datang',

];
