<?php

return [

    'title' => 'Վահանակ',

];
