<?php

return [

    'title' => 'Vezérlőpult',

    'actions' => [

        'filter' => [

            'label' => 'Szűrés',

            'modal' => [

                'heading' => 'Szűrés',

                'actions' => [

                    'apply' => [

                        'label' => 'Alkalmazás',

                    ],

                ],

            ],

        ],

    ],

];
