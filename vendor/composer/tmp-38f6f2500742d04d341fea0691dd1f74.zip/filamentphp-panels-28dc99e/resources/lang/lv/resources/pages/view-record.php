<?php

return [

    'title' => 'Skatīt :label',

    'breadcrumb' => 'Skatīt',

    'content' => [

        'tab' => [
            'label' => 'Skatīt',
        ],

    ],

];
