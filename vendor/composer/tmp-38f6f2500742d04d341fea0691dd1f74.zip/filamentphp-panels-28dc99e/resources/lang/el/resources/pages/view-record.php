<?php

return [

    'title' => 'Προεπισκόπηση :label',

    'breadcrumb' => 'Προεπισκόπηση',

    'content' => [

        'tab' => [
            'label' => 'Προεπισκόπηση',
        ],

    ],

];
