<?php

return [

    'title' => 'פאנל',

];
