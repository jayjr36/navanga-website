<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'সাইন আউট',
        ],

    ],

    'welcome' => 'স্বাগতম',

];
