<?php

return [

    'title' => 'ပင်မစာမျက်နှာ',

];
