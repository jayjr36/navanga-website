<?php

return [

    'title' => ':label ဖန်တီးပါ',

    'breadcrumb' => 'ဖန်တီးပါ',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'မလုပ်တော့ပါ',
            ],

            'create' => [
                'label' => 'ဖန်တီးပါ',
            ],

            'create_another' => [
                'label' => 'သိမ်းဆည်းပြီး နောက်တစ်ခုကို ဖန်တီးပါ',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'သိမ်းဆည်းပြီး',
        ],

    ],

];
