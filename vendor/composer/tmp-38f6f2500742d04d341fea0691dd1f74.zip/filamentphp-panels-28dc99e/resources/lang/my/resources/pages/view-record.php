<?php

return [

    'breadcrumb' => 'စစ်ဆေးပါ',

];
