<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Išsaugoti',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Išsaugota',
        ],

    ],

];
