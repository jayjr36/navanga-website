<?php

return [

    'title' => ':label bearbeiten',

    'breadcrumb' => 'Bearbeiten',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Abbrechen',
            ],

            'save' => [
                'label' => 'Speichern',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'Bearbeiten',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Gespeichert',
        ],

    ],

];
