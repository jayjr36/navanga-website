<?php

namespace Kirschbaum\PowerJoins;


trait PowerJoins
{
    //
}
