<?php

/*
 * You can place your custom package configuration in here.
 */
return [
    //
];
