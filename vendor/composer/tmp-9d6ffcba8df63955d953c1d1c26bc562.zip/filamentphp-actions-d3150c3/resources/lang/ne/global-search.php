<?php

return [

    'field' => [
        'label' => 'सार्वभौमिक खोजी',
        'placeholder' => 'खोज्नुहोस्',
    ],

    'no_results_message' => 'कुनै खोज परिणाम फेला परेन।',

];
