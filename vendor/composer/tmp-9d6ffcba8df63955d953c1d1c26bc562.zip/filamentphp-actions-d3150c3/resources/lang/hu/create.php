<?php

return [

    'single' => [

        'label' => 'Új :label',

        'modal' => [

            'heading' => 'Új :label',

            'actions' => [

                'create' => [
                    'label' => 'Létrehozás',
                ],

                'create_another' => [
                    'label' => 'Mentés és új létrehozása',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Létrehozva',
            ],

        ],

    ],

];
