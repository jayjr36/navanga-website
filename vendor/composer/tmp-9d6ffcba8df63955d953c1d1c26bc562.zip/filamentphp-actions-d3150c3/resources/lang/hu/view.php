<?php

return [

    'single' => [

        'label' => 'Megtekintés',

        'modal' => [

            'heading' => ':label megtekintése',

            'actions' => [

                'close' => [
                    'label' => 'Bezárás',
                ],

            ],

        ],

    ],

];
