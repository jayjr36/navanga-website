<?php

return [

    'confirmation' => 'ئایە دڵنیای لە کردنی ئەم کارە؟',

    'actions' => [

        'cancel' => [
            'label' => 'پاشگەزبوونەوە',
        ],

        'confirm' => [
            'label' => 'دڵنیام',
        ],

        'submit' => [
            'label' => 'ناردن',
        ],

    ],

];
