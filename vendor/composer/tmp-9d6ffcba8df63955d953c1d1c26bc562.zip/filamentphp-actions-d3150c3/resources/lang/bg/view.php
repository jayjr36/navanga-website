<?php

return [

    'single' => [

        'label' => 'Преглед',

        'modal' => [

            'heading' => 'Прегледай :label',

            'actions' => [

                'close' => [
                    'label' => 'Затвори',
                ],

            ],

        ],

    ],

];
