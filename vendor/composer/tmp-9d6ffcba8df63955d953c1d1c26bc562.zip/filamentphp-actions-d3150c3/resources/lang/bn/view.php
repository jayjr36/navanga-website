<?php

return [

    'single' => [

        'label' => 'দেখুন',

        'modal' => [

            'heading' => ':label দেখুন',

            'actions' => [

                'close' => [
                    'label' => 'বন্ধ করুন',
                ],

            ],

        ],

    ],

];
