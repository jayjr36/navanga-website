<?php

return [

    'trigger' => [
        'label' => 'কার্যক্রম',
    ],

];
