<?php

return [

    'single' => [

        'label' => 'Odebrat',

        'modal' => [

            'heading' => 'Odebrat :label',

            'actions' => [

                'detach' => [
                    'label' => 'Odebrat',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Odebráno',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Odebrat zvolené',

        'modal' => [

            'heading' => 'Odebrat zvolené :label',

            'actions' => [

                'detach' => [
                    'label' => 'Odebrat zvolené',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Odebráno',
            ],

        ],

    ],

];
