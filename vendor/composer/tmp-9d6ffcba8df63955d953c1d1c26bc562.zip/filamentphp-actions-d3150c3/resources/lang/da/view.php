<?php

return [

    'single' => [

        'label' => 'Vis',

        'modal' => [

            'heading' => 'Vis :label',

            'actions' => [

                'close' => [
                    'label' => 'Luk',
                ],

            ],

        ],

    ],

];
