<?php

return [

    'trigger' => [
        'label' => 'Handlinger',
    ],

];
