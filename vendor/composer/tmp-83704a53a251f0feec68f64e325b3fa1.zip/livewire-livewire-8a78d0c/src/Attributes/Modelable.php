<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportWireModelingNestedComponents\BaseModelable;

#[\Attribute]
class Modelable extends BaseModelable
{
    //
}
