<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => ':count件非表示',
                'expand_list' => ':count件表示',
            ],

            'more_list_items' => 'あと:count件あります',

        ],

    ],

];
