<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Zeige :count weniger',
                'expand_list' => 'Zeige :count weitere',
            ],

            'more_list_items' => 'und :count mehr',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Schlüssel',
                ],

                'value' => [
                    'label' => 'Wert',
                ],

            ],

            'placeholder' => 'Keine Einträge',

        ],

    ],

];
